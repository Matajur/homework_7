from setuptools import setup, find_namespace_packages

setup(name='clean_folder_matajur',
      version='0.0.1',
      description='file_sorter',
      url='http://github.com/dummy_user/useful',
      author='Dmytro Gavrylchenko',
      author_email='gavrylchenko.d@ukr.net',
      license='Apache Software License',
      packages=find_namespace_packages(),
      include_package_data=True,
      entry_points={'console_scripts': [
          'clean-folder = clean_folder.clean:main']}
      )
