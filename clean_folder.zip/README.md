This package contains script that sorts a selected folder.
The script accepts one argument at startup — the name of the folder in which it will sort.

The script parses the folder specified during the lauch and sorts all files into groups:

- images ('JPEG', 'PNG', 'JPG', 'SVG');
- video files ('AVI', 'MP4', 'MOV', 'MKV');
- documents ('DOC', 'DOCX', 'TXT', 'PDF', 'XLSX', 'PPTX');
- audio ('MP3', 'OGG', 'WAV', 'AMR');
- archives ('ZIP', 'GZ', 'TAR') are unpacked and their contents are transferred to the archives folder;
- unknown extensions.

During this operation:

- all files and folders are renamed using the normalize function.
- file extensions do not change after renaming.
- empty folders are deleted
- the script ignores archives, video, audio, documents, images folders;
- the unpacked contents of the archive are transferred to the archives folder in a subfolder named the same as the archive, but without the extension at the end;
- files whose extensions are unknown remain unchanged.
